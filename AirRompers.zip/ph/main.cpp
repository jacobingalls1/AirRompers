#include "mainFun.h"

int main() {

    srand(time(NULL));

    pushPlayer(Plane(Vector2f(0, 0), Vector2f(0, 0), 0, 3, PLAYER));
    pushPlayer(Plane(Vector2f(0, 0), Vector2f(0, 0), 0, 3, PLAYER));

    RenderWindow window(VideoMode(SCREEN_SIZE, SCREEN_SIZE), "Air Rompers: Player 1");
    window.requestFocus();
    window.setMouseCursorVisible(false);
    window.setFramerateLimit(30);

    RenderWindow window2(VideoMode(SCREEN_SIZE, SCREEN_SIZE), "Air Rompers: Player 2");
    window.requestFocus();
    window.setMouseCursorVisible(false);
    window.setFramerateLimit(30);

    while(window.isOpen()) {

        handle(window, window2);

        update();

        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            } else if (event.type == Event::KeyPressed) {
                switch (event.key.code) {
                    case Keyboard::Escape:
                    case Keyboard::Q:
                        window.close();
                        break;
                    case Keyboard::Left:
                        setKey(true, 0);
                        break;
                    case Keyboard::A:
                        setKey(true, 1);
                        break;
                    case Keyboard::Right:
                        setKey(true, 2);
                        break;
                    case Keyboard::D:
                        setKey(true, 3);
                        break;
                    case Keyboard::Up:
                        setKey(true, 4);
                        break;
                    case Keyboard::W:
                        setKey(true, 5);
                        break;
                    case Keyboard::Down:
                        setKey(true, 6);
                        beam(0);
                        break;
                    case Keyboard::S:
                        setKey(true, 7);
                        beam(1);
                        break;
                }
            } else if (event.type == Event::KeyReleased) {
                switch (event.key.code) {
                    case Keyboard::Left:
                        setKey(false, 0);
                        break;
                    case Keyboard::A:
                        setKey(false, 1);
                        break;
                    case Keyboard::Right:
                        setKey(false, 2);
                        break;
                    case Keyboard::D:
                        setKey(false, 3);
                        break;
                    case Keyboard::Up:
                        setKey(false, 4);
                        break;
                    case Keyboard::W:
                        setKey(false, 5);
                        break;
                    case Keyboard::Down:
                        setKey(false, 6);
                        break;
                    case Keyboard::S:
                        setKey(false, 7);
                        break;
                }
            }
        }
    }

    return EXIT_SUCCESS;
}
